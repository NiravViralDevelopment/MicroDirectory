<div class="padd_main">
	<div class="container">
		<div class="row">		    
			<div class="col-xs-12 col-sm-12 col-md-12">
				<?=$termsandconditions['description'];?>
			</div>
		</div>
	</div>
</div>