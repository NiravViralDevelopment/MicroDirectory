<table cellpadding='0' cellspacing='0' width='598px' style='border:1px solid #253f87;'>
	<tr>
		<td style='border-top:1px solid #000000;'><img src='<?php echo site_url('assets/images/email_top.jpg');?>'></td>
	</tr>
	<tr>
		<td style= ';min-height:500px; padding:10px;'>
			<table cellpadding='0' cellspacing='0' border=0 width='100%' align='center' style= 'font-family:Arial, Helvetica, sans-serif; font-size:14px;'>
				<tr align=left>
				<td>
				<table cellpadding='0' cellspacing='0' border=0 width='100%' style= 'font-family:Arial, Helvetica, sans-serif; font-size:14px;'>
						<tr>
							<td align=left height=30 colspan=2><p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 20px 0px; margin: 0px;"><b>Dear <?=ucwords($_POST['name'])?></b>,</p></td>
						</tr>
						<tr>
							<td align=left height=30 colspan="2">
							<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 20px 0px; margin: 0px;">I trust this email finds you well. Thank you for expressing your interest in ATOM.</p>
							<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 20px 0px; margin: 0px;">Please note that your registration will be approved after we receive your profile by email on info@atomdirectory.com</p>
							<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 20px 0px; margin: 0px;">Please send us the following details</p>
							<!-- <p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 20px 0px; margin: 0px;">Trade Union Affiliation: To foster a fair and transparent industry, we insist that production houses hold a valid affiliation with the trade union relevant to their industry.</p>
							<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 10px 0px; margin: 0px;"><strong>Documentation Requirements:</strong></p> -->
							<!-- <p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 14px 0px; margin: 0px;"><strong>For all New production houses and casting agencies</strong></p> -->
							<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 12px 0px; margin: 0px;">1) Company Name</p>
							<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 12px 0px; margin: 0px;">2) Company Address</p>
							<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 12px 0px; margin: 0px;">3) Company Registration Certificate</p>
							<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 12px 0px; margin: 0px;">4) Company TAN/PAN Card Copy</p>
							<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 12px 0px; margin: 0px;">5) Contact Person with Designation</p>
							<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 17px 0px; margin: 0px;">6) Contact Number for verification ( A personal Verification will be done by our executive)</p>
							<!-- <p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 10px 0px; margin: 0px;">A formal letter on the company letterhead with following details:</p>
							<ol style="margin: 0px; padding:0px 0px 20px 15px;">
								<li style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 10px 0px; margin: 0px;">Employee Name : </li>
								<li style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 10px 0px; margin: 0px;">Employee Contact Details : Official Email and Official Phone Number </li>
								<li style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 0px 0px; margin: 0px;">Employee Code : </li>
							</ol> -->
							
							<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 20px 0px; margin: 0px;">Thank you for your cooperation and understanding.</p>
							<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 5px 0px; margin: 0px;">Best regards,</p>
							<!-- [Your Name]<br> -->
							<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 5px 0px; margin: 0px;">ATOM Support Team</p>
							<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 5px 0px; margin: 0px;"><a style="color:#8BC34A; text-decoration: none;" href="https://atomdirectory.com/"> atomdirectory.com</a></p>
							</td>
						</tr>						
					</table>
				</td>
			</tr>
			<tr><td>&nbsp;</td></tr>
		</table>
		</td>
	</tr><tr>
	<td style='background: #2b2b2b none repeat scroll 0 0; border-top:1px solid #000000; line-height: 16px;  padding: 10px; color:#a6a6a6; font-family:Arial; font-size:12px; text-align:center;'>
		Copyright &copy; <?=date('Y')?> <?=$_POST['footer_V'];?>
		</td>
	</tr>
	
</table>