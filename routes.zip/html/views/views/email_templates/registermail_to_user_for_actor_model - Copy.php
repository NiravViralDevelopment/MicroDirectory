<table cellpadding='0' cellspacing='0' width='598px' style='border:1px solid #000000;'>
	<tr>
		<td style='border-top:1px solid #000000;'><img src='<?php echo site_url('assets/images/email_top.jpg');?>'></td>
	</tr>
	<tr>
		<td style='min-height:500px; padding:10px;'>
			<table cellpadding='0' cellspacing='0' border=0 width='100%' align='center' style= 'font-family:Arial, Helvetica, sans-serif; font-size:14px;'>
				<tr align=left>
				<td>
				<table cellpadding='0' cellspacing='0' border=0 width='100%' style= 'font-family:Arial, Helvetica, sans-serif; font-size:14px;'>
						<tr>
							<td align=left height=30 colspan=2><p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 20px 0px; margin: 0px;"><b>Dear <?=ucwords($_POST['name'])?></b>,</p></td>
						</tr>
						<tr>
							<td align=left height=30 colspan="2">
								<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 20px 0px; margin: 0px;">Welcome to ATOM Directory, where dreams meet opportunities in the thrilling world of entertainment! We are happy to have you on board as a valued member of our growing community.</p>
								<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 20px 0px; margin: 0px;">At ATOM, we understand the unique journey of you as an actor or model. We are committed to providing you with the tools and resources needed to thrive in the dynamic entertainment industry.</p>
								<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 20px 0px; margin: 0px;"><b>Your Profile Showcase should present you in the best possible way.</b></p>
								<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 20px 0px; margin: 0px;">Creating a stunning profile that highlights your skills, experience, and unique talents gives you a chance to make a lasting impression on industry professionals.</p>
								<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 20px 0px; margin: 0px;">Before you move further, please note that if you do not follow the standards of photos and videos required by ATOM, your profile will be rejected and your account blocked.</p>
								<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 20px 0px; margin: 0px;">Please ensure that your profile doesn’t make the casting department to reject you. We don’t want you to take selfies or photos taken with your mobile.</p>
								<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 20px 0px; margin: 0px;">Go to a photo studio and just take 4 to 6  photographs in a clean and blank White / Gray back ground.  Don’t spend more than Rs.2000 on your photographs.</p>
								<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 20px 0px; margin: 0px;">Create one single audition video in the language that you prefer.</p>
								<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 20px 0px; margin: 0px;"><strong><i>Please see the link to get an idea about how your profile should look like</i></strong></p>
								<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 20px 0px; margin: 0px;"><a style="color:#8BC34A; text-decoration: none;" href="https://atomdirectory.com/directory_detail/freshers/nikhar-pradhan">https://atomdirectory.com/directory_detail/freshers/nikhar-pradhan </a></p>
								<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 5px 0px; margin: 0px;"><i>We reject your entries not because we don’t need you, but it is because we don’t want your profile to be rejected by production houses.</i></p>
							</td>
						</tr>
						
					</table>
				</td>
			</tr>
			<tr><td>&nbsp;</td></tr>
		</table>
		</td>
	</tr><tr>
		<td style='background: #2b2b2b none repeat scroll 0 0; border-top:1px solid #000000; line-height: 16px;  padding: 10px; color:#a6a6a6; font-family:Arial; font-size:12px; text-align:center;'>
		Copyright &copy; <?=date('Y')?> <?=$_POST['footer_V'];?>
		</td>
	</tr>
	
</table>