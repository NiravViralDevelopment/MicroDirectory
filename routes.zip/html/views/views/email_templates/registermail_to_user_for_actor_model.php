<table cellpadding='0' cellspacing='0' width='598px' style='border:1px solid #000000;'>
	<tr>
		<td style='border-top:1px solid #000000;'><img src='<?php echo site_url('assets/images/email_top.jpg');?>'></td>
	</tr>
	<tr>
		<td style='min-height:500px; padding:10px;'>
			<table cellpadding='0' cellspacing='0' border=0 width='100%' align='center' style= 'font-family:Arial, Helvetica, sans-serif; font-size:14px;'>
				<tr align=left>
				<td>
				<table cellpadding='0' cellspacing='0' border=0 width='100%' style= 'font-family:Arial, Helvetica, sans-serif; font-size:14px;'>
						<tr>
							<td align=left height=30 colspan=2><p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 20px 0px; margin: 0px;"><b>Dear <?=ucwords($_POST['name'])?></b>,</p></td>
						</tr>
						<tr>
							<td align=left height=30 colspan="2">
								<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 20px 0px; margin: 0px;">Welcome to ATOM Directory, where dreams meet opportunities.</p>
								<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 20px 0px; margin: 0px;">Thank you for expressing your interest in ATOM. We appreciate your enthusiasm and commitment to enhancing your profile within our community.</p>
								
								<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 20px 0px; margin: 0px;">At ATOM, we understand the unique journey of you as an actor or model. We are committed to providing you with the tools and resources needed to promote yourself</p>
								
								<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 20px 0px; margin: 0px;">Your Profile Showcase should present you in the best possible way.</p>
								
								
								<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 20px 0px; margin: 0px;">Creating a good profile that highlights your skills, experience, and unique talents gives you a chance to make a lasting impression on industry professionals.</p>
								
								
								<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 20px 0px; margin: 0px;">Important Points to Note :</p>
								
								<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 20px 0px; margin: 0px;">Production houses prioritize professionalism in photos and videos. To ensure your profile is well-received by industry professionals, we strongly recommend investing in high-quality, professional photos and videos.</p>
								
								<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 20px 0px; margin: 0px;">Don’t’s</p>
								<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 0px 0px; margin: 0px;">1.     Don’t take selfies or photos taken with your mobile.</p>
								<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 20px 0px; margin: 0px;">2.     Don’t take your audition video with too much background noise.</p>
								
								<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 20px 0px; margin: 0px;">Do’s</p>
								<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 10px 0px; margin: 0px;">1.     Go to a photo studio and just take 4 to 6  photographs in a clean and blank White / Gray back ground.  Don’t spend more than Rs.2000 on your photographs.</p>
								<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 20px 0px; margin: 0px;">2.     Create one single audition video in the language that you prefer in a clean environment preferably with a white background and no external background noises.</p>
								
								<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 20px 0px; margin: 0px;">Please see the link to get an idea about how your profile should look like</p>
								<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 20px 0px; margin: 0px;">To further assist you, we invite you to review the sample profile we have created for you by following this link:</p>
								<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 20px 0px; margin: 0px;"><a style="color:#8BC34A; text-decoration: none;" href="https://atomdirectory.com/directory_detail/actor/abhishek-arya"> https://atomdirectory.com/directory_detail/actor/abhishek-arya</a></p>
								<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 20px 0px; margin: 0px;">Before you move further, please note that if you do not follow the standards of photos and videos required by ATOM, your profile will be rejected and your account blocked.</p>
								<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 20px 0px; margin: 0px;">We will reject your entries not because we don’t need you, but it is because we don’t want your profile to be rejected by production houses.</p>
								<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 20px 0px; margin: 0px;">Please send the above details by email to <a href="mailto:info@atomdirectory.com"><u>info@atomdirectory.com </u></a></p>
								<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 20px 0px; margin: 0px;">Should you have any questions or require further assistance in optimizing your profile, please don't hesitate to reach out.</p>
								<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 20px 0px; margin: 0px;">Thank you for your cooperation and understanding.</p>
								
								
								
								
								
								
								
								
								
								
								
								
								
								
								
								<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 5px 0px; margin: 0px;">Best regards,<br></p>
							<!-- [Your Name]<br> -->
							<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 5px 0px; margin: 0px;">ATOM Support Team</p>
							<p style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000; line-height: 17px; padding: 0px 0px 5px 0px; margin: 0px;"><a style="color:#8BC34A; text-decoration: none;" href="https://atomdirectory.com/"> atomdirectory.com</a></p>
							</td>
						</tr>
						
					</table>
				</td>
			</tr>
			<tr><td>&nbsp;</td></tr>
		</table>
		</td>
	</tr><tr>
		<td style='background: #2b2b2b none repeat scroll 0 0; border-top:1px solid #000000; line-height: 16px;  padding: 10px; color:#a6a6a6; font-family:Arial; font-size:12px; text-align:center;'>
		Copyright &copy; <?=date('Y')?> <?=$_POST['footer_V'];?>
		</td>
	</tr>
	
</table>