<div class="padd_main minHeightnone">
    <div class="container">
        <div class="about-content content-block paddset1">
            <h1 class="fnt20">Thank you for registering with ATOM Directory.</h1>
            <p class="fnt20">Thank you for registering. Please check your inbox for an email from
                info@atomdirectory.com. If it is not in your inbox please do check the spam folder.</p>
            <p class="fnt17">Please connect with us info@atomdirectory.com for any further queries.</p>
        </div>
    </div>
</div>