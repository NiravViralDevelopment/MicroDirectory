<div id="globalFooter" class="printorder">
	<div id="footer">
		<div class="copyRight">Copyright &copy; <?=date('Y')?> <?=ADMIN_FOOTER_SITENAME?> All rights reserved.</div>
		<div class="siteCreated">Site By : <a href="http://www.meghtechnologies.com/" target="_blank">Megh Technologies</a></div>
	</div>
	<div class="clear"></div>
</div>