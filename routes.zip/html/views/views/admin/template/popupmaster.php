<?php $this->load->view('admin/includes/header');?>
<div id="pageWrapper">
	<div  class="adminContainer">
		<div class="clear"></div>
         <?php $this->load->view($main);?>
	</div>
	<div class="push"></div>
</div>