<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class RoleInfoController extends Controller
{
    //
}
