<!-- ======= Sidebar ======= -->

<aside id="sidebar" class="sidebar">
  <div class="clickSlick">
    <i class="bi bi-chevron-right toggle-sidebar-btn"></i>
  </div>
    <ul class="sidebar-nav" id="sidebar-nav">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Dashboard')): ?>
        <li class="nav-item <?php echo e(Route::currentRouteName() == 'dashboard' ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
                <img src="<?php echo e(asset('admin')); ?>/img/dashboard.png" class="img-fluid iconNav hide" alt="dashboard icon">
                <img src="<?php echo e(asset('admin')); ?>/img/dashboard-white.png" class="img-fluid iconNav show" alt="dashboard icon"> <!-- Dashboard icon -->
                <span>Dashboard</span>
            </a>
        </li>
        <?php endif; ?>

        <li class="nav-item <?php echo e(in_array(Route::currentRouteName(), ['roles.index', 'roles.edit', 'roles.show','roles.create']) ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('roles.index')); ?>">
                <img src="<?php echo e(asset('admin')); ?>/img/roles.png" class="img-fluid iconNav hide" alt="role icon">
                <img src="<?php echo e(asset('admin')); ?>/img/roles-white.png" class="img-fluid iconNav show" alt="role icon"> <!-- Roles icon -->
                <span>Category</span>
            </a>
        </li>

        

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-list')): ?>
            <li class="nav-item dropdown <?php echo e(in_array(Route::currentRouteName(), ['countries.index', 'countries.create', 'countries.edit', 'states.index', 'states.create', 'states.edit', 'cities.index', 'cities.create', 'cities.edit', 'experiences.index', 'experiences.create', 'experiences.edit','languages.index', 'languages.create', 'languages.edit','products.index', 'products.create', 'products.edit']) ? 'active' : ''); ?>">
                <a class="nav-link collapsed" data-bs-toggle="collapse" href="#usersSubMenu" aria-expanded="<?php echo e(in_array(Route::currentRouteName(), ['countries.index', 'countries.create', 'countries.edit', 'states.index', 'states.create', 'states.edit', 'cities.index', 'cities.create', 'cities.edit', 'experiences.index', 'experiences.create', 'experiences.edit','languages.index', 'languages.create', 'languages.edit','products.index', 'products.create', 'products.edit']) ? 'true' : 'false'); ?>">
                    <img src="<?php echo e(asset('admin')); ?>/img/users.png" class="img-fluid iconNav hide" alt="users icon">
                    <img src="<?php echo e(asset('admin')); ?>/img/users-white.png" class="img-fluid iconNav show" alt="users icon">
                    <span>Master</span>
                    <i class="bi bi-chevron-down ms-auto"></i>
                </a>
                <ul id="usersSubMenu" class="nav-content collapse <?php echo e(in_array(Route::currentRouteName(), ['countries.index', 'countries.create', 'countries.edit', 'states.index', 'states.create', 'states.edit', 'cities.index', 'cities.create', 'cities.edit', 'experiences.index', 'experiences.create', 'experiences.edit','languages.index', 'languages.create', 'languages.edit','products.index', 'products.create', 'products.edit','service.index', 'service.create', 'service.edit']) ? 'show' : ''); ?>" data-bs-parent="#sidebar-nav">
                    <li>
                       <a href="<?php echo e(route('countries.index')); ?>" class="<?php echo e(in_array(Route::currentRouteName(), ['countries.index', 'countries.create', 'countries.edit']) ? 'active' : ''); ?>">
                            <i class="bi bi-circle"></i><span>Country</span>
                        </a>
                    </li>

                    <li>
                       <a href="<?php echo e(route('states.index')); ?>" class="<?php echo e(in_array(Route::currentRouteName(), ['states.index', 'states.create', 'states.edit']) ? 'active' : ''); ?>">
                            <i class="bi bi-circle"></i><span>State</span>
                        </a>
                    </li>

                    <li>
                       <a href="<?php echo e(route('cities.index')); ?>" class="<?php echo e(in_array(Route::currentRouteName(), ['cities.index', 'cities.create', 'cities.edit']) ? 'active' : ''); ?>">
                            <i class="bi bi-circle"></i><span>City</span>
                        </a>
                    </li>

                    <li>
                        <a href="<?php echo e(route('experiences.index')); ?>" class="<?php echo e(in_array(Route::currentRouteName(), ['experiences.index', 'experiences.create', 'experiences.edit']) ? 'active' : ''); ?>">
                            <i class="bi bi-circle"></i><span>Speciality</span>
                        </a>
                    </li>

                    <li>
                        <a href="<?php echo e(route('languages.index')); ?>" class="<?php echo e(in_array(Route::currentRouteName(), ['languages.index', 'languages.create', 'languages.edit']) ? 'active' : ''); ?>">
                            <i class="bi bi-circle"></i><span>Language</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('products.index')); ?>"class="<?php echo e(in_array(Route::currentRouteName(), ['products.index', 'products.create', 'products.edit']) ? 'active' : ''); ?>">
                            <i class="bi bi-circle"></i><span>Product</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('service.index')); ?>"class="<?php echo e(in_array(Route::currentRouteName(), ['service.index', 'service.create', 'service.edit']) ? 'active' : ''); ?>">
                            <i class="bi bi-circle"></i><span>Services</span>
                        </a>
                    </li>

                </ul>
            </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Manage Countries')): ?>
            <li class="nav-item <?php echo e(in_array(Route::currentRouteName(), ['users.index', 'users.create','users.edit','users.show']) ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('users.index')); ?>">
                    <img src="<?php echo e(asset('admin')); ?>/img/order-items.png" class="img-fluid iconNav hide" alt="order items icon">
                    <img src="<?php echo e(asset('admin')); ?>/img/order-items-white.png" class="img-fluid iconNav show" alt="role icon"> <!-- Order-Items icon -->
                    <span> Member Directory </span>
                </a>
            </li>
        <?php endif; ?>

        <li class="nav-item">
            <a class="nav-link <?php echo e(Request::is('cms*') ? 'active' : ''); ?>" href="<?php echo e(route('cms.index')); ?>">
                <img src="<?php echo e(asset('admin')); ?>/img/order-items.png" class="img-fluid iconNav hide" alt="order items icon">
                <img src="<?php echo e(asset('admin')); ?>/img/order-items-white.png" class="img-fluid iconNav show" alt="role icon">
                <span>CMS</span>
            </a>
        </li>

        


    </ul>
  </aside>
<?php /**PATH C:\wamp64\www\attom_directory\resources\views/layouts/admin/sidebaar.blade.php ENDPATH**/ ?>