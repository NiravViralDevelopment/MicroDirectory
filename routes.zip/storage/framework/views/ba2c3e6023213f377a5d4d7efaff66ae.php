<?php $__env->startSection('content'); ?>
<div class="container">
    <h3>User Images</h3>
    <a href="<?php echo e(route('users.index')); ?>" class="btn btn-secondary mb-3">
    <i class="fa fa-arrow-left"></i> Back to Users
</a>

    <a href="<?php echo e(route('user-images.create', ['user_id' => request('user_id')])); ?>" class="btn btn-primary mb-3">Add New Image</a>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>No</th>
                <th>Image</th>
                <th>Status</th>
                <th>Created At</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $userImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($index + 1); ?></td>
                    <td>
                        <?php if($img->image): ?>
                            <img src="<?php echo e(asset('storage/'.$img->image)); ?>" alt="User Image" style="width: 100px; height: auto;">
                        <?php endif; ?>
                    </td>
                    <td>
                        <span class="badge <?php echo e($img->status ? 'bg-success' : 'bg-danger'); ?>">
                            <?php echo e($img->status ? 'Active' : 'Inactive'); ?>

                        </span>
                    </td>
                    <td><?php echo e($img->created_at->format('Y-m-d')); ?></td>
                    <td>
                        <a href="<?php echo e(route('user-images.edit', $img->id)); ?>" class="btn btn-sm btn-primary">Edit</a>
                        <form action="<?php echo e(route('user-images.destroy', $img->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button onclick="return confirm('Are you sure?')" class="btn btn-sm btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if($userImages->isEmpty()): ?>
                <tr><td colspan="5" class="text-center">No images found.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\attom_directory\resources\views/user-images/index.blade.php ENDPATH**/ ?>