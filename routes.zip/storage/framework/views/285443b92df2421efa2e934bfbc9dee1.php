
<script src="https://code.jquery.com/jquery-1.11.3.js"></script>
<?php $__env->startSection('content'); ?>
    <section class="section">
      <div class="row">
        <div class="col-lg-12">

          <div class="card cardPdd">
            <div class="card-body topText">
              <div class="flexBdy">
                <div class="pull-left">
                  <h5 class="card-title">Edit City</h5>
                </div>
                <div class="pull-right">
                  <a class="btn btn-sm mb-2 comnBtn whtTxt borderBtn" href="<?php echo e(route('cities.index')); ?>">Back</a>
                </div>
              </div>
            </div>

            <!-- Horizontal Form -->
            <div class="frmGrp antherGrp">
              <form action="<?php echo e(route('cities.update', $city->id)); ?>" method="POST" id="cityForm">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="row mb-3">
                  <label for="country_id" class="col-sm-1 col-form-label strng flexCntr">Country <span class="text-danger">*</span></label>
                  <div class="col-sm-5">
                    <select name="country_id" class="form-control required" id="country_id">
                      <option value="">Select Country</option>
                      <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($country->id); ?>" <?php echo e((old('country_id', $city->country_id) == $country->id) ? 'selected' : ''); ?>>
                          <?php echo e($country->name); ?>

                        </option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['country_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>

                <div class="row mb-3">
                  <label for="state_id" class="col-sm-1 col-form-label strng flexCntr">State <span class="text-danger">*</span></label>
                  <div class="col-sm-5">
                    <select name="state_id" class="form-control required" id="state_id">
                      <option value="">Select State</option>
                      <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($state->id); ?>" <?php echo e((old('state_id', $city->state_id) == $state->id) ? 'selected' : ''); ?>>
                          <?php echo e($state->name); ?>

                        </option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['state_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>

                <div class="row mb-3">
                  <label for="name" class="col-sm-1 col-form-label strng flexCntr">Name <span class="text-danger">*</span></label>
                  <div class="col-sm-5">
                    <input type="text" name="name" value="<?php echo e(old('name', $city->name)); ?>" class="form-control required" id="name">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>

                <div class="row mb-3">
                  <label for="code" class="col-sm-1 col-form-label strng flexCntr">Code <span class="text-danger">*</span></label>
                  <div class="col-sm-5">
                    <input type="text" name="code" value="<?php echo e(old('code', $city->code)); ?>" class="form-control required" id="code">
                    <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>

                <input type="hidden" name="is_active" value="<?php echo e($city->is_active); ?>">

                <div class="mt50 pddLftStLow">
                  <button type="submit" class="btn btn-sm comnBtn">Update</button>
                </div>
              </form>
            </div>
          </div>

        </div>
      </div>
    </section>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.5/jquery.validate.min.js"></script>
    <?php $__env->startPush('scripts'); ?>
    <script>
    $(document).ready(function() {
        // Handle country change
        $('#country_id').on('change', function() {
            var countryId = $(this).val();
            var stateSelect = $('#state_id');
            
            // Clear current state selection
            stateSelect.empty().append('<option value="">Select State</option>');
            
            if (countryId) {
                console.log('Fetching states for country:', countryId);
                
                // Show loading state
                stateSelect.prop('disabled', true);
                
                $.ajax({
                    url: '<?php echo e(route("states.get-by-country")); ?>',
                    type: 'GET',
                    data: { country_id: countryId },
                    dataType: 'json',
                    success: function(response) {
                        console.log('States response:', response);
                        
                        if (response && response.states) {
                            var states = response.states;
                            if (states.length > 0) {
                                // Add states to dropdown
                                $.each(states, function(index, state) {
                                    stateSelect.append(
                                        $('<option></option>')
                                            .val(state.id)
                                            .text(state.name)
                                    );
                                });
                                
                                // If we have a selected state, try to select it
                                var selectedStateId = '<?php echo e(old("state_id", $city->state_id)); ?>';
                                if (selectedStateId) {
                                    stateSelect.val(selectedStateId);
                                }
                            } else {
                                console.log('No states found for country');
                                stateSelect.append('<option value="">No states available</option>');
                            }
                        } else {
                            console.error('Invalid response format:', response);
                            stateSelect.append('<option value="">Error loading states</option>');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Error fetching states:', {
                            status: status,
                            error: error,
                            response: xhr.responseText
                        });
                        stateSelect.append('<option value="">Error loading states</option>');
                    },
                    complete: function() {
                        // Re-enable state select
                        stateSelect.prop('disabled', false);
                    }
                });
            }
        });

        // Form validation
        $('#cityForm').validate({
            rules: {
                country_id: {
                    required: true
                },
                state_id: {
                    required: true
                },
                name: {
                    required: true
                },
                code: {
                    required: true
                }
            },
            messages: {
                country_id: {
                    required: "Please select a country"
                },
                state_id: {
                    required: "Please select a state"
                },
                name: {
                    required: "Please enter city name"
                },
                code: {
                    required: "Please enter city code"
                }
            },
            errorElement: 'span',
            errorPlacement: function(error, element) {
                error.addClass('invalid-feedback');
                element.closest('.form-group').append(error);
            },
            highlight: function(element, errorClass, validClass) {
                $(element).addClass('is-invalid');
            },
            unhighlight: function(element, errorClass, validClass) {
                $(element).removeClass('is-invalid');
            }
        });

        // Trigger change event if country is pre-selected
        if($('#country_id').val()) {
            $('#country_id').trigger('change');
        }
    });
    </script>
    <?php $__env->stopPush(); ?>
    <style>
      .error {
        color: red;
      }
    </style>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\attom_directory\resources\views/cities/edit.blade.php ENDPATH**/ ?>