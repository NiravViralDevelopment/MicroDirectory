<?php $__env->startSection('content'); ?>
<div class="container">
    <h3>Edit User Image</h3>
    <a href="<?php echo e(route('user-images.index', ['user_id' => $userImage->user_id])); ?>" class="btn btn-secondary mb-3">Back</a>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('user-images.update', $userImage->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-3">
            <label for="image" class="form-label">Current Image</label><br>
            <?php if($userImage->image): ?>
                <img src="<?php echo e(asset('storage/'.$userImage->image)); ?>" alt="User Image" style="width: 150px; height: auto;">
            <?php endif; ?>
        </div>

        <div class="mb-3">
            <label for="image" class="form-label">Change Image (optional)</label>
            <input type="file" class="form-control" id="image" name="image">
        </div>

        <div class="form-check mb-3">
            <input class="form-check-input" type="checkbox" name="status" id="status" value="1" <?php echo e($userImage->status ? 'checked' : ''); ?>>
            <label class="form-check-label" for="status">Active</label>
        </div>

        <button type="submit" class="btn btn-primary">Update Image</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\attom_directory\resources\views/user-images/edit.blade.php ENDPATH**/ ?>