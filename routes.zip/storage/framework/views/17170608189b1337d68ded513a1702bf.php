<?php $__env->startSection('content'); ?>
<div class="container">
    <h3>Add New Document</h3>

    <form action="<?php echo e(route('manage-documents.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="user_id" value="<?php echo e($userId); ?>">

        <div class="mb-3">
            <label for="document" class="form-label">Upload Document</label>
            <input type="file" name="document" id="document" class="form-control" required>
            <?php $__errorArgs = ['document'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-check mb-3">
            <input type="checkbox" name="status" id="status" class="form-check-input" checked>
            <label for="status" class="form-check-label">Active</label>
        </div>

        <button type="submit" class="btn btn-success">Save Document</button>
        <a href="<?php echo e(route('manage-documents.index', ['user_id' => $userId])); ?>" class="btn btn-secondary">Cancel</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\attom_directory\resources\views/manage-documents/create.blade.php ENDPATH**/ ?>