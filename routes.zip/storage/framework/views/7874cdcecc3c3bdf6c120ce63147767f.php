<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Add Video</h2>

    <form action="<?php echo e(route('video-galleries.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="user_id" value="<?php echo e($selectedUserId); ?>">

        <div class="mb-3">
            <label for="link" class="form-label">Video Link (URL)</label>
            <input type="url" class="form-control <?php $__errorArgs = ['link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="link" name="link" value="<?php echo e(old('link')); ?>" required>
            <?php $__errorArgs = ['link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-check mb-3">
            <input class="form-check-input" type="checkbox" name="is_active" id="is_active" checked>
            <label class="form-check-label" for="is_active">Active</label>
        </div>

        <button type="submit" class="btn btn-primary">Add Video</button>
        <a href="<?php echo e(route('video-galleries.index', ['user_id' => $selectedUserId])); ?>" class="btn btn-secondary">Cancel</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\attom_directory\resources\views/video-galleries/create.blade.php ENDPATH**/ ?>