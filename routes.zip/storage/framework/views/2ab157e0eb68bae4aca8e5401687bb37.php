<?php $__env->startSection('content'); ?>
<div class="container">
    <h3>Manage Documents</h3>
    <a href="<?php echo e(route('manage-documents.create', ['user_id' => $userId])); ?>" class="btn btn-primary mb-3">Add New Document</a>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>No</th>
                <th>Document</th>
                <th>Status</th>
                <th>Uploaded At</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($index + 1); ?></td>
                    <td>
                        <?php if($doc->document): ?>
                            <a href="<?php echo e(asset('storage/' . $doc->document)); ?>" target="_blank">
                                <?php echo e(basename($doc->document)); ?>

                            </a>
                        <?php endif; ?>
                    </td>
                    <td>
                        <span class="badge <?php echo e($doc->status ? 'bg-success' : 'bg-danger'); ?>">
                            <?php echo e($doc->status ? 'Active' : 'Inactive'); ?>

                        </span>
                    </td>
                    <td><?php echo e($doc->created_at->format('Y-m-d')); ?></td>
                    <td>
                        <a href="<?php echo e(route('manage-documents.edit', $doc->id)); ?>" class="btn btn-sm btn-primary">Edit</a>
                        <form action="<?php echo e(route('manage-documents.destroy', $doc->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button onclick="return confirm('Are you sure?')" class="btn btn-sm btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="5" class="text-center">No documents found.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\attom_directory\resources\views/manage-documents/index.blade.php ENDPATH**/ ?>