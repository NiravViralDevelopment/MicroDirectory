<script src="https://code.jquery.com/jquery-1.11.3.js"></script>
<?php $__env->startSection('content'); ?>

<div class="row">
<div class="col-lg-12">
<div class="card cardPdd">
    <div class="card-body topText">
        <div class="col-lg-12 margin-tb">
            <div class="flexBdy">
            <div class="pull-left">
                <h5 class="card-title"> Edit</h5>
            </div>

            <div class="pull-right">
                <a class="btn btn-sm mb-2 comnBtn whtTxt borderBtn" href="<?php echo e(route('service.index')); ?>"> Back</a>
            </div>
            </div>
        </div>
    </div>
    <section class="section frmGrp">
      <div class="row">
        <div class="col-lg-12">


              <!-- Horizontal Form -->
              <form action="<?php echo e(route('service.update',$Service->id)); ?>" method="POST" enctype="multipart/form-data"> <?php echo csrf_field(); ?>
<?php echo method_field('put'); ?>
                <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-1 col-form-label strng flexCntr"> Service<span class="text-danger">*</span></label>
                  <div class="col-sm-5">
                    <input type="text" name="title" value="<?php echo e($Service->title); ?>" class="form-control" id="inputText">
                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>

                 <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-1 col-form-label strng flexCntr"> Category <span class="text-danger">*</span></label>
                  <div class="col-sm-5">
                   <select name="category_id" id="" class="form-control required" >
                    <option value="">Select</option>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($role->id); ?>" <?php if($Service->category_id == $role->id): ?> selected <?php endif; ?>><?php echo e($role->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </select>
                   </div>
                </div>

                <div class="row mb-3">
                    <label for="is_active" class="col-sm-1 col-form-label strng flexCntr"> Active </label>
                    <div class="col-sm-5 d-flex align-items-center">
                                <input type="hidden" name="is_active" value="0">

                        <input type="checkbox" name="is_active" id="is_active" value="1" <?php echo e($Service->is_active == 1 ? 'checked' : ''); ?>>
                    </div>
                </div>


                <div class="text-left mt50 pddLftStLow">
                  <button type="submit" class="btn btn-sm comnBtn whtTxt">Update</button>

                </div>
              </form>

          </div>
        </div>

    </section>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\attom_directory\resources\views/service/edit.blade.php ENDPATH**/ ?>