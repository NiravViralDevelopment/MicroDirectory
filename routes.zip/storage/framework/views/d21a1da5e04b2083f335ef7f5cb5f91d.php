<?php $__env->startSection('content'); ?>
<div class="row">
<div class="col-lg-12">
<div class="card cardPdd">
    <div class="card-body topText">
    <div class="col-lg-12 margin-tb">
        <div class="flexBdy">
                <div class="pull-left">
                   <h5 class="card-title">Create New Category</h5>
                </div>
                <div class="pull-right">
                   <a class="btn btn-sm mb-2 comnBtn whtTxt borderBtn" href="<?php echo e(route('roles.index')); ?>"><i class="fa fa-arrow-left"></i> Back</a>
                </div>
            </div>
    </div>
    </div>


<?php if(count($errors) > 0): ?>
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<div class="frmGrp">
<form method="POST" action="<?php echo e(route('roles.store')); ?>" id="role" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-6">
            <div class="form-group">
                <strong class="strng">Name:</strong>
                <input type="text" name="name" placeholder="Enter Name" value="<?php echo e(old('name')); ?>" class="form-control required">
            </div>
        </div>

         <div class="col-xs-12 col-sm-12 col-md-6">
            <div class="form-group">
                <strong class="strng">image:</strong>
                <input type="file" name="image"  class="form-control required">
            </div>
        </div>

         

         

         

        <div class="col-xs-12 col-sm-12 col-md-6">
            <div class="form-group">
                <strong class="strng">Active:</strong>
                 <input type="checkbox" name="is_active" id="is_active" value="1" <?php echo e(old('is_active', true) ? 'checked' : ''); ?>>
            </div>
        </div>


           <input type="hidden" name="is_active" value="0">


        
        <div class="col-xs-12 col-sm-12 col-md-12 mt50">
            <button type="submit" class="btn btn-sm comnBtn"><i class="fa-solid fa-floppy-disk"></i> Submit</button>
        </div>
    </div>
</form>
</div>

</div>
</div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.5/jquery.validate.min.js"></script>
<script>
    $(document).ready(function() {
        // alert("well done");

        $("#role").validate({
            errorClass: "error"
        });

    });
    </script>
    <style>
        .error {
            color: red;

        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\attom_directory\resources\views/roles/create.blade.php ENDPATH**/ ?>