<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Video Gallery</h2>
<a href="<?php echo e(route('users.index')); ?>" class="btn btn-secondary mb-3">
    <i class="fa fa-arrow-left"></i> Back to Users
</a>
    <a href="<?php echo e(route('video-galleries.create', ['user_id' => request('user_id')])); ?>" class="btn btn-primary mb-3">
        Add New Video
    </a>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>#</th>
                <th>Video Link</th>
                <th>Status</th>
                <th>Created At</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($index + 1); ?></td>
                <td><a href="<?php echo e($video->link); ?>" target="_blank"><?php echo e(\Illuminate\Support\Str::limit($video->link, 50)); ?></a></td>
                <td>
                    <span class="badge <?php echo e($video->is_active ? 'bg-success' : 'bg-danger'); ?>">
                        <?php echo e($video->is_active ? 'Active' : 'Inactive'); ?>

                    </span>
                </td>
                <td><?php echo e($video->created_at->format('Y-m-d')); ?></td>
                <td>
                    <a href="<?php echo e(route('video-galleries.edit', $video->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                    <form action="<?php echo e(route('video-galleries.destroy', $video->id)); ?>" method="POST" style="display:inline-block;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-sm btn-danger" onclick="return confirm('Delete this video?')">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="5">No videos found.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\attom_directory\resources\views/video-galleries/index.blade.php ENDPATH**/ ?>